import javax.swing.*;
import java.util.LinkedList;

public class ClinicRuslan {
    public static void main(String [] args){
        /*==Variable Declaration, Object Constructs=============================================================*/
        String name="";
        String IC="";			//MYKad No
        String contactNo="";	//Use string to get zero at the front e.g. 0134567890
        String address="";
        String gender="";
        int age=0;
        //String date="";		//reservation date
        double time=0.0;		//reservation time
        String priority="";	    //normal or critical
        //
        int choice = 0;
        String option = "";
        String output = "";
        //Setting Queue
        Queue normalQueue = new Queue();
        Queue priorityQueue = new Queue();;
        Patient temp;
        LinkedList AllQueue = new LinkedList();/*
		AllQueue.add(normalQueue);
		AllQueue.add(priorityQueue);*/


        /*==MAIN CONTENT=============================================================*/
        while (choice==0){
            option=JOptionPane.showInputDialog(null,"Choose Option\n\tAdd\n\tDelete\n\tView\n\tExit");
            /*==Add=============================================================*/
            if (option.equalsIgnoreCase("Add"))
            {
                //JOptionPane.showMessageDialog(null,"ADDING");
                name=JOptionPane.showInputDialog(null,"Name");
                IC=JOptionPane.showInputDialog(null,"IC");
                contactNo=JOptionPane.showInputDialog(null,"Contact No");
                address=JOptionPane.showInputDialog(null,"Address");
                gender=JOptionPane.showInputDialog(null,"Gender[Male/Female]");
                age=Integer.parseInt(JOptionPane.showInputDialog(null,"Age"));
                time=Double.parseDouble(JOptionPane.showInputDialog(null,"Time[24hours system]"));
                priority=JOptionPane.showInputDialog(null,"Priority[normal/critical]");
                temp = new Patient(name,IC,contactNo,address,gender,age,time,priority);
                if (temp.priorityCheck())
                {
                    priorityQueue.enqueue(temp);  //Queue for Critical Priority Condition
                }
                else
                {
                    normalQueue.enqueue(temp);	  //Queue for Normal Patients
                }
            }
            /*==Delete=============================================================*/
            else if (option.equalsIgnoreCase("Delete"))
            {
                //View First
                if(!priorityQueue.isEmpty())
                {
                    for(int i=0; i<priorityQueue.size(); i++)
                    {
                        temp = (Patient) priorityQueue.front();
                        //System.out.println(temp.toString());
                        output+=temp.toString();
                    }
                }
                if(!normalQueue.isEmpty())
                {
                    for(int i=0; i<normalQueue.size(); i++)
                    {
                        temp = (Patient) normalQueue.front();
                        //System.out.println(temp.toString());
                        output+=temp.toString();
                    }
                }
                JOptionPane.showMessageDialog(null,"Select which patient?(Define the name.)\n"+output);
                output="";

            }
            /*==View=============================================================*/
            else if (option.equalsIgnoreCase("View"))
            {
				/*for(int i=0; i<AllQueue.size(); i++)
					{
					temp = (Patient) AllQueue.get(i);
					System.out.println(temp.toString());
					}*/
                if(!priorityQueue.isEmpty())
                {
                    for(int i=0; i<priorityQueue.size(); i++)
                    {
                        temp = (Patient) priorityQueue.front();
                        //System.out.println(temp.toString());
                        output+=temp.toString();
                    }
                }
                if(!normalQueue.isEmpty())
                {
                    for(int i=0; i<normalQueue.size(); i++)
                    {
                        temp = (Patient) normalQueue.front();
                        //System.out.println(temp.toString());
                        output+=temp.toString();
                    }
                }
                JOptionPane.showMessageDialog(null,"VIEWING\n"+output);
                output="";

            }
            /*==Exit=============================================================*/
            else if (option.equalsIgnoreCase("Exit"))
                break;
                /*==Error Input Notification=============================================================*/
            else
                JOptionPane.showMessageDialog(new JFrame(), "You have entered invalid input. Please enter \"Add\", \"Delete\", \"View\", or \"Exit\" ", "Wrong Input",JOptionPane.ERROR_MESSAGE);
            /*==Choose to continue or not=============================================================*/
            choice=JOptionPane.showConfirmDialog(null,"Do you want to continue?","Continue?", JOptionPane.YES_NO_OPTION);//return 0 for yes option.
        }
        /*==END MAIN CONTENT=============================================================*/
        System.exit(0);
    }
}
