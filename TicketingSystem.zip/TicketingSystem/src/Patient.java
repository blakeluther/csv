public class Patient {
    protected String name;
    protected String IC;			//MYKad No
    protected String contactNo;
    protected String address;
    protected String gender;
    protected int age;
    //protected String date;		//reservation date
    protected double time;		//reservation time
    protected String priority;	//normal or critical

    //Patient(String a,String b,int c,String d,String e,int f,String g,double h,String i){
    Patient(String a,String b,String c,String d,String e,int f,double h,String i){
        name=a;
        IC=b;
        contactNo=c;
        address=d;
        gender=e;
        age=f;
        //date=g;
        time=h;
        priority=i;
    }

    public String getName(){return name;}
    public String getIC(){return IC;}
    public String getContact(){return contactNo;}
    public String getAddress(){return address;}
    public String getGender(){return gender;}
    public int getAge(){return age;}
    //public String getDate(){return date;}
    public double getTime(){return time;}
    public String getPriority(){return priority;}

    public boolean priorityCheck(){
        if (getPriority().equalsIgnoreCase("critical"))
            return true;
        else
            return false;
    }

    public String toString(){
        return "Name: " + getName() + ", IC No: " + getIC() + ", Contact no : " +  getContact() + ", Address : " +  getAddress() + ", Gender : "
                +  getGender() +  ", Age : " + getAge() + ", Time : " + getTime() + ", Condition : " +  getPriority() + "\n";
    }
}
